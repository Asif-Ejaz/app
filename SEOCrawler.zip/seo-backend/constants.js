
this.RESPONSE_DATA = {
    "internal_links": {
        "errMsg": null,
        "response": {
            "internalLinks": [
                "https://itu.edu.pk/health",
                "https://itu.edu.pk/itu-latest-news/online-examinations-schedules-for-spring-2020/",
                "https://itu.edu.pk/about/",
                "https://itu.edu.pk/quality-enhancement-cell/",
                "https://itu.edu.pk",
                "https://itu.edu.pk/",
                "https://itu.edu.pk/faculty-itu/",
                "https://itu.edu.pk/admissions/",
                "https://itu.edu.pk/admissions/covid-19-admissions-announcement/",
                "https://itu.edu.pk/admissions/application-process/",
                "https://itu.edu.pk/admissions#admissions-calendar",
                "https://itu.edu.pk/financial-assistance/",
                "https://itu.edu.pk/kamyab-jawan-program/",
                "https://itu.edu.pk/admissions#undergraduate",
                "https://itu.edu.pk/admissions/bs-economics-with-data-science/#verticalTab1",
                "https://itu.edu.pk/admissions/bs-computer-engineering/#verticalTab1",
                "https://itu.edu.pk/admissions/bs-computer-science/#verticalTab1",
                "https://itu.edu.pk/admissions/bs-electrical-engineering/#verticalTab1",
                "https://itu.edu.pk/admissions/bachelors-of-science-in-management-and-technology/#verticalTab1",
                "https://itu.edu.pk/admissions#graduate",
                "https://itu.edu.pk/admissions/embite/",
                "https://itu.edu.pk/admissions/msdevs/",
                "https://itu.edu.pk/admissions/ms-electrical-engineering/#verticalTab1",
                "https://itu.edu.pk/admissions/ms-computer-science/#verticalTab1",
                "https://itu.edu.pk/admissions/ms-data-science/#verticalTab1",
                "https://itu.edu.pk/admissions/phd-electrical-engineering/#verticalTab1",
                "https://itu.edu.pk/admissions/phd-computer-science/#verticalTab1",
                "https://itu.edu.pk/admissions/faqs/",
                "https://itu.edu.pk/academics/",
                "https://itu.edu.pk/itu-latest-news/",
                "https://itu.edu.pk/press-clippings/",
                "https://itu.edu.pk/research/",
                "https://itu.edu.pk/newsevents/dr-sarfraz-khurshid-joins-itu-as-new-vc/",
                "https://itu.edu.pk/itu-latest-news/first-electrical-engineering-public-phd-defense/",
                "https://itu.edu.pk/online/",
                "https://itu.edu.pk/admissions/#admissions-calendar",
                "https://itu.edu.pk/lincoln-corners/",
                "https://itu.edu.pk/up-events/usl-opening-ceremony/",
                "https://itu.edu.pk/up-events/launching-ceremony-of-prime-ministers-kamyab-jawan-programme/",
                "https://itu.edu.pk/up-events/the-center-for-digital-humanities-multiplayer-online-boards-competition/",
                "https://itu.edu.pk/up-events/",
                "https://itu.edu.pk/engineering-labs/",
                "https://itu.edu.pk/about/student-societies/",
                "https://itu.edu.pk/it-capacity-building/",
                "https://itu.edu.pk/faculty-itu/dr-akmal-hussain/",
                "https://itu.edu.pk/faculty-itu/dr-adnan-noor-mian/",
                "https://itu.edu.pk/faculty-itu/dr-tauseef-tauqeer/",
                "https://itu.edu.pk/faculty-itu/dr-junaid-qadir/",
                "https://itu.edu.pk/faculty-itu/izza-aftab/",
                "https://itu.edu.pk/faculty-itu/dr-arif-mahmood/",
                "https://itu.edu.pk/faculty-itu/dr-sajid-ahmed/",
                "https://itu.edu.pk/faculty-itu/dr-usman-younis/",
                "https://itu.edu.pk/faculty-itu/dr-khurram-bhatti/",
                "https://itu.edu.pk/faculty-itu/dr-muhammad-mahboob-ur-rahman/",
                "https://itu.edu.pk/faculty-itu/muddasir-shabbir/",
                "https://itu.edu.pk/faculty-itu/mohsen-ali/",
                "https://itu.edu.pk/faculty-itu/dr-hina-khalid/",
                "https://itu.edu.pk/faculty-itu/aftab-alam/",
                "https://itu.edu.pk/academics/grading-policy/",
                "https://itu.edu.pk/academics/forms-and-documents/",
                "https://itu.edu.pk/about/library/",
                "https://itu.edu.pk/academics/programs-course-outline/",
                "https://itu.edu.pk/pdc/",
                "https://itu.edu.pk/admissions/msdevs",
                "https://itu.edu.pk/academics/fee-structure/",
                "https://itu.edu.pk/careers/",
                "https://itu.edu.pk/tenders",
                "https://itu.edu.pk/itu-act",
                "https://itu.edu.pk/about",
                "https://itu.edu.pk/careers",
                "https://itu.edu.pk/contact"
            ],
            "status": "success",
            "message": ""
        }
    },
    "external_links": {
        "errMsg": null,
        "response": {
            "externalLinks": [
                "#",
                "http://convocation.itu.edu.pk/",
                "http://convocation.itu.edu.pk/convocation2017",
                "http://www.technologyreview.pk/?lang=en",
                "http://oric.itu.edu.pk/",
                "https://vimeo.com/327893562",
                "https://vimeo.com/327893562?width=640&height=400",
                "https://vimeo.com/207091966?width=640&height=400",
                "http://library.itu.edu.pk/",
                "http://sdgtl.itu.edu.pk/",
                "http://makeistan.itu.edu.pk/",
                "http://fm.itu.edu.pk/",
                "mailto:admission@itu.edu.pk",
                "https://twitter.com/ITUPunjab",
                "https://www.facebook.com/ITU.punjab?fref=ts",
                "https://www.linkedin.com/company/itu---information-technology-university",
                "https://www.instagram.com/itu_punjab/"
            ],
            "status": "success",
            "message": ""
        }
    },
    "meta_description": {
        "errMsg": null,
        "response": {
            "metaDescription": "ITU aims to implement a unique teaching methodology and cross-disciplinary research that is grounded in real-world problem solving to educate the next generation of innovative and entrepreneurial engineers.",
            "status": "passed",
            "message": ""
        }
    },
    "meta_keyword": {
        "errMsg": null,
        "response": {
            "metaKeyword": null,
            "status": "failed",
            "message": "Your site doesn't have meta keywords"
        }
    },
    "title": {
        "errMsg": null,
        "response": {
            "title": "Information Technology University | Information Technology University",
            "status": "failed",
            "message": "Your title length has greater than 60 charcters"
        }
    },
    "robot": {
        "errMsg": null,
        "response": {
            "text": "",
            "status": "failed",
            "message": "Your site doesn't have robot.txt"
        }
    },
    "sitemap": {
        "errMsg": null,
        "response": {
            "location": null,
            "status": "failed",
            "message": "Your site doesn't have sitemap.xml"
        }
    },
    "single": [
        [
            [
                "BS"
            ],
            5
        ],
        [
            [
                "PROGRAMS"
            ],
            4
        ],
        [
            [
                "Science"
            ],
            4
        ],
        [
            [
                "MS"
            ],
            4
        ],
        [
            [
                "Technology"
            ],
            3
        ],
        [
            [
                "Computer"
            ],
            3
        ],
        [
            [
                "Engineering"
            ],
            3
        ],
        [
            [
                "Information"
            ],
            2
        ],
        [
            [
                "University"
            ],
            2
        ],
        [
            [
                "ADMISSIONS"
            ],
            2
        ],
        [
            [
                "Admissions"
            ],
            2
        ],
        [
            [
                "UNDERGRADUATE"
            ],
            2
        ],
        [
            [
                "Data"
            ],
            2
        ],
        [
            [
                "Electrical"
            ],
            2
        ],
        [
            [
                "GRADUATE"
            ],
            2
        ],
        [
            [
                "PhD"
            ],
            2
        ],
        [
            [
                "NEWS"
            ],
            2
        ],
        [
            [
                "2020"
            ],
            1
        ],
        [
            [
                "|"
            ],
            1
        ],
        [
            [
                "Menu"
            ],
            1
        ],
        [
            [
                "HOME"
            ],
            1
        ],
        [
            [
                "FACULTY"
            ],
            1
        ],
        [
            [
                "Covid-19"
            ],
            1
        ],
        [
            [
                "Announcement"
            ],
            1
        ],
        [
            [
                "Overview"
            ],
            1
        ],
        [
            [
                "Application"
            ],
            1
        ],
        [
            [
                "Process"
            ],
            1
        ],
        [
            [
                "Calendar"
            ],
            1
        ],
        [
            [
                "Scholarships"
            ],
            1
        ],
        [
            [
                "Kamyab"
            ],
            1
        ],
        [
            [
                "Jawan"
            ],
            1
        ],
        [
            [
                "Program"
            ],
            1
        ],
        [
            [
                "Economics"
            ],
            1
        ],
        [
            [
                "with"
            ],
            1
        ],
        [
            [
                "Management"
            ],
            1
        ],
        [
            [
                "and"
            ],
            1
        ],
        [
            [
                "Executive"
            ],
            1
        ],
        [
            [
                "MBA"
            ],
            1
        ],
        [
            [
                "Development"
            ],
            1
        ],
        [
            [
                "Studies"
            ],
            1
        ],
        [
            [
                "ELECTRICAL"
            ],
            1
        ],
        [
            [
                "ENGINEERING"
            ],
            1
        ],
        [
            [
                "COMPUTER"
            ],
            1
        ],
        [
            [
                "SCIENCE"
            ],
            1
        ],
        [
            [
                "FAQs"
            ],
            1
        ],
        [
            [
                "ACADEMICS"
            ],
            1
        ],
        [
            [
                "EVENTS"
            ],
            1
        ],
        [
            [
                "AND"
            ],
            1
        ],
        [
            [
                "HAPPENINGS"
            ],
            1
        ],
        [
            [
                "Press"
            ],
            1
        ],
        [
            [
                "Clippings"
            ],
            1
        ],
        [
            [
                "RESEARCH"
            ],
            1
        ]
    ],
    "two": [
        [
            [
                "Information",
                "Technology"
            ],
            2
        ],
        [
            [
                "Technology",
                "University"
            ],
            2
        ],
        [
            [
                "UNDERGRADUATE",
                "PROGRAMS"
            ],
            2
        ],
        [
            [
                "Data",
                "Science"
            ],
            2
        ],
        [
            [
                "Science",
                "BS"
            ],
            2
        ],
        [
            [
                "BS",
                "Computer"
            ],
            2
        ],
        [
            [
                "Engineering",
                "BS"
            ],
            2
        ],
        [
            [
                "Computer",
                "Science"
            ],
            2
        ],
        [
            [
                "Electrical",
                "Engineering"
            ],
            2
        ],
        [
            [
                "GRADUATE",
                "PROGRAMS"
            ],
            2
        ],
        [
            [
                "University",
                "|"
            ],
            1
        ],
        [
            [
                "|",
                "Information"
            ],
            1
        ],
        [
            [
                "University",
                "Menu"
            ],
            1
        ],
        [
            [
                "Menu",
                "HOME"
            ],
            1
        ],
        [
            [
                "HOME",
                "FACULTY"
            ],
            1
        ],
        [
            [
                "FACULTY",
                "ADMISSIONS"
            ],
            1
        ],
        [
            [
                "ADMISSIONS",
                "ADMISSIONS"
            ],
            1
        ],
        [
            [
                "ADMISSIONS",
                "Covid-19"
            ],
            1
        ],
        [
            [
                "Covid-19",
                "Admissions"
            ],
            1
        ],
        [
            [
                "Admissions",
                "Announcement"
            ],
            1
        ],
        [
            [
                "Announcement",
                "Overview"
            ],
            1
        ],
        [
            [
                "Overview",
                "Application"
            ],
            1
        ],
        [
            [
                "Application",
                "Process"
            ],
            1
        ],
        [
            [
                "Process",
                "Admissions"
            ],
            1
        ],
        [
            [
                "Admissions",
                "Calendar"
            ],
            1
        ],
        [
            [
                "Calendar",
                "2020"
            ],
            1
        ],
        [
            [
                "2020",
                "Scholarships"
            ],
            1
        ],
        [
            [
                "Scholarships",
                "Kamyab"
            ],
            1
        ],
        [
            [
                "Kamyab",
                "Jawan"
            ],
            1
        ],
        [
            [
                "Jawan",
                "Program"
            ],
            1
        ],
        [
            [
                "Program",
                "UNDERGRADUATE"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "UNDERGRADUATE"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "BS"
            ],
            1
        ],
        [
            [
                "BS",
                "Economics"
            ],
            1
        ],
        [
            [
                "Economics",
                "with"
            ],
            1
        ],
        [
            [
                "with",
                "Data"
            ],
            1
        ],
        [
            [
                "Computer",
                "Engineering"
            ],
            1
        ],
        [
            [
                "BS",
                "Electrical"
            ],
            1
        ],
        [
            [
                "BS",
                "Management"
            ],
            1
        ],
        [
            [
                "Management",
                "and"
            ],
            1
        ],
        [
            [
                "and",
                "Technology"
            ],
            1
        ],
        [
            [
                "Technology",
                "GRADUATE"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "GRADUATE"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "Executive"
            ],
            1
        ],
        [
            [
                "Executive",
                "MBA"
            ],
            1
        ],
        [
            [
                "MBA",
                "MS"
            ],
            1
        ],
        [
            [
                "MS",
                "Development"
            ],
            1
        ],
        [
            [
                "Development",
                "Studies"
            ],
            1
        ],
        [
            [
                "Studies",
                "MS"
            ],
            1
        ],
        [
            [
                "MS",
                "Electrical"
            ],
            1
        ],
        [
            [
                "Engineering",
                "MS"
            ],
            1
        ],
        [
            [
                "MS",
                "Computer"
            ],
            1
        ],
        [
            [
                "Science",
                "MS"
            ],
            1
        ],
        [
            [
                "MS",
                "Data"
            ],
            1
        ],
        [
            [
                "Science",
                "PhD"
            ],
            1
        ],
        [
            [
                "PhD",
                "ELECTRICAL"
            ],
            1
        ],
        [
            [
                "ELECTRICAL",
                "ENGINEERING"
            ],
            1
        ],
        [
            [
                "ENGINEERING",
                "PhD"
            ],
            1
        ],
        [
            [
                "PhD",
                "COMPUTER"
            ],
            1
        ],
        [
            [
                "COMPUTER",
                "SCIENCE"
            ],
            1
        ],
        [
            [
                "SCIENCE",
                "FAQs"
            ],
            1
        ],
        [
            [
                "FAQs",
                "ACADEMICS"
            ],
            1
        ],
        [
            [
                "ACADEMICS",
                "NEWS"
            ],
            1
        ],
        [
            [
                "NEWS",
                "NEWS"
            ],
            1
        ],
        [
            [
                "NEWS",
                "EVENTS"
            ],
            1
        ],
        [
            [
                "EVENTS",
                "AND"
            ],
            1
        ],
        [
            [
                "AND",
                "HAPPENINGS"
            ],
            1
        ],
        [
            [
                "HAPPENINGS",
                "Press"
            ],
            1
        ],
        [
            [
                "Press",
                "Clippings"
            ],
            1
        ],
        [
            [
                "Clippings",
                "RESEARCH"
            ],
            1
        ]
    ],
    "three": [
        [
            [
                "Information",
                "Technology",
                "University"
            ],
            2
        ],
        [
            [
                "Technology",
                "University",
                "|"
            ],
            1
        ],
        [
            [
                "University",
                "|",
                "Information"
            ],
            1
        ],
        [
            [
                "|",
                "Information",
                "Technology"
            ],
            1
        ],
        [
            [
                "Technology",
                "University",
                "Menu"
            ],
            1
        ],
        [
            [
                "University",
                "Menu",
                "HOME"
            ],
            1
        ],
        [
            [
                "Menu",
                "HOME",
                "FACULTY"
            ],
            1
        ],
        [
            [
                "HOME",
                "FACULTY",
                "ADMISSIONS"
            ],
            1
        ],
        [
            [
                "FACULTY",
                "ADMISSIONS",
                "ADMISSIONS"
            ],
            1
        ],
        [
            [
                "ADMISSIONS",
                "ADMISSIONS",
                "Covid-19"
            ],
            1
        ],
        [
            [
                "ADMISSIONS",
                "Covid-19",
                "Admissions"
            ],
            1
        ],
        [
            [
                "Covid-19",
                "Admissions",
                "Announcement"
            ],
            1
        ],
        [
            [
                "Admissions",
                "Announcement",
                "Overview"
            ],
            1
        ],
        [
            [
                "Announcement",
                "Overview",
                "Application"
            ],
            1
        ],
        [
            [
                "Overview",
                "Application",
                "Process"
            ],
            1
        ],
        [
            [
                "Application",
                "Process",
                "Admissions"
            ],
            1
        ],
        [
            [
                "Process",
                "Admissions",
                "Calendar"
            ],
            1
        ],
        [
            [
                "Admissions",
                "Calendar",
                "2020"
            ],
            1
        ],
        [
            [
                "Calendar",
                "2020",
                "Scholarships"
            ],
            1
        ],
        [
            [
                "2020",
                "Scholarships",
                "Kamyab"
            ],
            1
        ],
        [
            [
                "Scholarships",
                "Kamyab",
                "Jawan"
            ],
            1
        ],
        [
            [
                "Kamyab",
                "Jawan",
                "Program"
            ],
            1
        ],
        [
            [
                "Jawan",
                "Program",
                "UNDERGRADUATE"
            ],
            1
        ],
        [
            [
                "Program",
                "UNDERGRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "UNDERGRADUATE",
                "PROGRAMS",
                "UNDERGRADUATE"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "UNDERGRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "UNDERGRADUATE",
                "PROGRAMS",
                "BS"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "BS",
                "Economics"
            ],
            1
        ],
        [
            [
                "BS",
                "Economics",
                "with"
            ],
            1
        ],
        [
            [
                "Economics",
                "with",
                "Data"
            ],
            1
        ],
        [
            [
                "with",
                "Data",
                "Science"
            ],
            1
        ],
        [
            [
                "Data",
                "Science",
                "BS"
            ],
            1
        ],
        [
            [
                "Science",
                "BS",
                "Computer"
            ],
            1
        ],
        [
            [
                "BS",
                "Computer",
                "Engineering"
            ],
            1
        ],
        [
            [
                "Computer",
                "Engineering",
                "BS"
            ],
            1
        ],
        [
            [
                "Engineering",
                "BS",
                "Computer"
            ],
            1
        ],
        [
            [
                "BS",
                "Computer",
                "Science"
            ],
            1
        ],
        [
            [
                "Computer",
                "Science",
                "BS"
            ],
            1
        ],
        [
            [
                "Science",
                "BS",
                "Electrical"
            ],
            1
        ],
        [
            [
                "BS",
                "Electrical",
                "Engineering"
            ],
            1
        ],
        [
            [
                "Electrical",
                "Engineering",
                "BS"
            ],
            1
        ],
        [
            [
                "Engineering",
                "BS",
                "Management"
            ],
            1
        ],
        [
            [
                "BS",
                "Management",
                "and"
            ],
            1
        ],
        [
            [
                "Management",
                "and",
                "Technology"
            ],
            1
        ],
        [
            [
                "and",
                "Technology",
                "GRADUATE"
            ],
            1
        ],
        [
            [
                "Technology",
                "GRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "GRADUATE",
                "PROGRAMS",
                "GRADUATE"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "GRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "GRADUATE",
                "PROGRAMS",
                "Executive"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "Executive",
                "MBA"
            ],
            1
        ],
        [
            [
                "Executive",
                "MBA",
                "MS"
            ],
            1
        ],
        [
            [
                "MBA",
                "MS",
                "Development"
            ],
            1
        ],
        [
            [
                "MS",
                "Development",
                "Studies"
            ],
            1
        ],
        [
            [
                "Development",
                "Studies",
                "MS"
            ],
            1
        ],
        [
            [
                "Studies",
                "MS",
                "Electrical"
            ],
            1
        ],
        [
            [
                "MS",
                "Electrical",
                "Engineering"
            ],
            1
        ],
        [
            [
                "Electrical",
                "Engineering",
                "MS"
            ],
            1
        ],
        [
            [
                "Engineering",
                "MS",
                "Computer"
            ],
            1
        ],
        [
            [
                "MS",
                "Computer",
                "Science"
            ],
            1
        ],
        [
            [
                "Computer",
                "Science",
                "MS"
            ],
            1
        ],
        [
            [
                "Science",
                "MS",
                "Data"
            ],
            1
        ],
        [
            [
                "MS",
                "Data",
                "Science"
            ],
            1
        ],
        [
            [
                "Data",
                "Science",
                "PhD"
            ],
            1
        ],
        [
            [
                "Science",
                "PhD",
                "ELECTRICAL"
            ],
            1
        ],
        [
            [
                "PhD",
                "ELECTRICAL",
                "ENGINEERING"
            ],
            1
        ],
        [
            [
                "ELECTRICAL",
                "ENGINEERING",
                "PhD"
            ],
            1
        ],
        [
            [
                "ENGINEERING",
                "PhD",
                "COMPUTER"
            ],
            1
        ],
        [
            [
                "PhD",
                "COMPUTER",
                "SCIENCE"
            ],
            1
        ],
        [
            [
                "COMPUTER",
                "SCIENCE",
                "FAQs"
            ],
            1
        ],
        [
            [
                "SCIENCE",
                "FAQs",
                "ACADEMICS"
            ],
            1
        ],
        [
            [
                "FAQs",
                "ACADEMICS",
                "NEWS"
            ],
            1
        ],
        [
            [
                "ACADEMICS",
                "NEWS",
                "NEWS"
            ],
            1
        ],
        [
            [
                "NEWS",
                "NEWS",
                "EVENTS"
            ],
            1
        ],
        [
            [
                "NEWS",
                "EVENTS",
                "AND"
            ],
            1
        ],
        [
            [
                "EVENTS",
                "AND",
                "HAPPENINGS"
            ],
            1
        ],
        [
            [
                "AND",
                "HAPPENINGS",
                "Press"
            ],
            1
        ],
        [
            [
                "HAPPENINGS",
                "Press",
                "Clippings"
            ],
            1
        ],
        [
            [
                "Press",
                "Clippings",
                "RESEARCH"
            ],
            1
        ]
    ],
    "four": [
        [
            [
                "Information",
                "Technology",
                "University",
                "|"
            ],
            1
        ],
        [
            [
                "Technology",
                "University",
                "|",
                "Information"
            ],
            1
        ],
        [
            [
                "University",
                "|",
                "Information",
                "Technology"
            ],
            1
        ],
        [
            [
                "|",
                "Information",
                "Technology",
                "University"
            ],
            1
        ],
        [
            [
                "Information",
                "Technology",
                "University",
                "Menu"
            ],
            1
        ],
        [
            [
                "Technology",
                "University",
                "Menu",
                "HOME"
            ],
            1
        ],
        [
            [
                "University",
                "Menu",
                "HOME",
                "FACULTY"
            ],
            1
        ],
        [
            [
                "Menu",
                "HOME",
                "FACULTY",
                "ADMISSIONS"
            ],
            1
        ],
        [
            [
                "HOME",
                "FACULTY",
                "ADMISSIONS",
                "ADMISSIONS"
            ],
            1
        ],
        [
            [
                "FACULTY",
                "ADMISSIONS",
                "ADMISSIONS",
                "Covid-19"
            ],
            1
        ],
        [
            [
                "ADMISSIONS",
                "ADMISSIONS",
                "Covid-19",
                "Admissions"
            ],
            1
        ],
        [
            [
                "ADMISSIONS",
                "Covid-19",
                "Admissions",
                "Announcement"
            ],
            1
        ],
        [
            [
                "Covid-19",
                "Admissions",
                "Announcement",
                "Overview"
            ],
            1
        ],
        [
            [
                "Admissions",
                "Announcement",
                "Overview",
                "Application"
            ],
            1
        ],
        [
            [
                "Announcement",
                "Overview",
                "Application",
                "Process"
            ],
            1
        ],
        [
            [
                "Overview",
                "Application",
                "Process",
                "Admissions"
            ],
            1
        ],
        [
            [
                "Application",
                "Process",
                "Admissions",
                "Calendar"
            ],
            1
        ],
        [
            [
                "Process",
                "Admissions",
                "Calendar",
                "2020"
            ],
            1
        ],
        [
            [
                "Admissions",
                "Calendar",
                "2020",
                "Scholarships"
            ],
            1
        ],
        [
            [
                "Calendar",
                "2020",
                "Scholarships",
                "Kamyab"
            ],
            1
        ],
        [
            [
                "2020",
                "Scholarships",
                "Kamyab",
                "Jawan"
            ],
            1
        ],
        [
            [
                "Scholarships",
                "Kamyab",
                "Jawan",
                "Program"
            ],
            1
        ],
        [
            [
                "Kamyab",
                "Jawan",
                "Program",
                "UNDERGRADUATE"
            ],
            1
        ],
        [
            [
                "Jawan",
                "Program",
                "UNDERGRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "Program",
                "UNDERGRADUATE",
                "PROGRAMS",
                "UNDERGRADUATE"
            ],
            1
        ],
        [
            [
                "UNDERGRADUATE",
                "PROGRAMS",
                "UNDERGRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "UNDERGRADUATE",
                "PROGRAMS",
                "BS"
            ],
            1
        ],
        [
            [
                "UNDERGRADUATE",
                "PROGRAMS",
                "BS",
                "Economics"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "BS",
                "Economics",
                "with"
            ],
            1
        ],
        [
            [
                "BS",
                "Economics",
                "with",
                "Data"
            ],
            1
        ],
        [
            [
                "Economics",
                "with",
                "Data",
                "Science"
            ],
            1
        ],
        [
            [
                "with",
                "Data",
                "Science",
                "BS"
            ],
            1
        ],
        [
            [
                "Data",
                "Science",
                "BS",
                "Computer"
            ],
            1
        ],
        [
            [
                "Science",
                "BS",
                "Computer",
                "Engineering"
            ],
            1
        ],
        [
            [
                "BS",
                "Computer",
                "Engineering",
                "BS"
            ],
            1
        ],
        [
            [
                "Computer",
                "Engineering",
                "BS",
                "Computer"
            ],
            1
        ],
        [
            [
                "Engineering",
                "BS",
                "Computer",
                "Science"
            ],
            1
        ],
        [
            [
                "BS",
                "Computer",
                "Science",
                "BS"
            ],
            1
        ],
        [
            [
                "Computer",
                "Science",
                "BS",
                "Electrical"
            ],
            1
        ],
        [
            [
                "Science",
                "BS",
                "Electrical",
                "Engineering"
            ],
            1
        ],
        [
            [
                "BS",
                "Electrical",
                "Engineering",
                "BS"
            ],
            1
        ],
        [
            [
                "Electrical",
                "Engineering",
                "BS",
                "Management"
            ],
            1
        ],
        [
            [
                "Engineering",
                "BS",
                "Management",
                "and"
            ],
            1
        ],
        [
            [
                "BS",
                "Management",
                "and",
                "Technology"
            ],
            1
        ],
        [
            [
                "Management",
                "and",
                "Technology",
                "GRADUATE"
            ],
            1
        ],
        [
            [
                "and",
                "Technology",
                "GRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "Technology",
                "GRADUATE",
                "PROGRAMS",
                "GRADUATE"
            ],
            1
        ],
        [
            [
                "GRADUATE",
                "PROGRAMS",
                "GRADUATE",
                "PROGRAMS"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "GRADUATE",
                "PROGRAMS",
                "Executive"
            ],
            1
        ],
        [
            [
                "GRADUATE",
                "PROGRAMS",
                "Executive",
                "MBA"
            ],
            1
        ],
        [
            [
                "PROGRAMS",
                "Executive",
                "MBA",
                "MS"
            ],
            1
        ],
        [
            [
                "Executive",
                "MBA",
                "MS",
                "Development"
            ],
            1
        ],
        [
            [
                "MBA",
                "MS",
                "Development",
                "Studies"
            ],
            1
        ],
        [
            [
                "MS",
                "Development",
                "Studies",
                "MS"
            ],
            1
        ],
        [
            [
                "Development",
                "Studies",
                "MS",
                "Electrical"
            ],
            1
        ],
        [
            [
                "Studies",
                "MS",
                "Electrical",
                "Engineering"
            ],
            1
        ],
        [
            [
                "MS",
                "Electrical",
                "Engineering",
                "MS"
            ],
            1
        ],
        [
            [
                "Electrical",
                "Engineering",
                "MS",
                "Computer"
            ],
            1
        ],
        [
            [
                "Engineering",
                "MS",
                "Computer",
                "Science"
            ],
            1
        ],
        [
            [
                "MS",
                "Computer",
                "Science",
                "MS"
            ],
            1
        ],
        [
            [
                "Computer",
                "Science",
                "MS",
                "Data"
            ],
            1
        ],
        [
            [
                "Science",
                "MS",
                "Data",
                "Science"
            ],
            1
        ],
        [
            [
                "MS",
                "Data",
                "Science",
                "PhD"
            ],
            1
        ],
        [
            [
                "Data",
                "Science",
                "PhD",
                "ELECTRICAL"
            ],
            1
        ],
        [
            [
                "Science",
                "PhD",
                "ELECTRICAL",
                "ENGINEERING"
            ],
            1
        ],
        [
            [
                "PhD",
                "ELECTRICAL",
                "ENGINEERING",
                "PhD"
            ],
            1
        ],
        [
            [
                "ELECTRICAL",
                "ENGINEERING",
                "PhD",
                "COMPUTER"
            ],
            1
        ],
        [
            [
                "ENGINEERING",
                "PhD",
                "COMPUTER",
                "SCIENCE"
            ],
            1
        ],
        [
            [
                "PhD",
                "COMPUTER",
                "SCIENCE",
                "FAQs"
            ],
            1
        ],
        [
            [
                "COMPUTER",
                "SCIENCE",
                "FAQs",
                "ACADEMICS"
            ],
            1
        ],
        [
            [
                "SCIENCE",
                "FAQs",
                "ACADEMICS",
                "NEWS"
            ],
            1
        ],
        [
            [
                "FAQs",
                "ACADEMICS",
                "NEWS",
                "NEWS"
            ],
            1
        ],
        [
            [
                "ACADEMICS",
                "NEWS",
                "NEWS",
                "EVENTS"
            ],
            1
        ],
        [
            [
                "NEWS",
                "NEWS",
                "EVENTS",
                "AND"
            ],
            1
        ],
        [
            [
                "NEWS",
                "EVENTS",
                "AND",
                "HAPPENINGS"
            ],
            1
        ],
        [
            [
                "EVENTS",
                "AND",
                "HAPPENINGS",
                "Press"
            ],
            1
        ],
        [
            [
                "AND",
                "HAPPENINGS",
                "Press",
                "Clippings"
            ],
            1
        ],
        [
            [
                "HAPPENINGS",
                "Press",
                "Clippings",
                "RESEARCH"
            ],
            1
        ]
    ]
}

this.RESPONSE_ADVANCE = {
    "headers": {
        "errMsg": null,
        "response": {
            "header": {
                "h1": [],
                "h2": [],
                "h3": [
                    "02:30pm - 05:30pm",
                    "10:00am - 03:00pm",
                    "Online Competition -",
                    "Library",
                    "Sdg Tech Lab",
                    "Event",
                    "State of the Art Campus",
                    "Engineering Lab",
                    "Makistan",
                    "ITU FM Radio",
                    "Embeded Lab",
                    "Sports"
                ],
                "h4": [
                    "2nd Convocation 2019",
                    "2nd Convocation 2019",
                    "ITU 1st convocation 2017",
                    "Lincoln Corner, a partnership project of ITU",
                    "DISCOVER NEW KNOWLEDGE, LEAD INNOVATION, AND TRANSFORM OUR FUTURE"
                ],
                "h5": [],
                "h6": []
            },
            "status": "passed",
            "message": "header exists "
        }
    },
    "is_mobile_friendly": {
        "errMsg": null,
        "response": {
            "isMobileFriendly": true,
            "status": "passed",
            "message": "This site is mobile friendly"
        }
    },
    "frameworks": {
        "urls": {
            "https://itu.edu.pk/": {
                "status": 200
            }
        },
        "technologies": [
            {
                "slug": "wordpress",
                "name": "WordPress",
                "confidence": 100,
                "version": "5.6",
                "icon": "WordPress.svg",
                "website": "https://wordpress.org",
                "cpe": "cpe:/a:wordpress:wordpress",
                "categories": [
                    {
                        "id": 1,
                        "slug": "cms",
                        "name": "CMS"
                    },
                    {
                        "id": 11,
                        "slug": "blogs",
                        "name": "Blogs"
                    }
                ]
            },
            {
                "slug": "mysql",
                "name": "MySQL",
                "confidence": 100,
                "version": null,
                "icon": "MySQL.svg",
                "website": "http://mysql.com",
                "cpe": "cpe:/a:mysql:mysql",
                "categories": [
                    {
                        "id": 34,
                        "slug": "databases",
                        "name": "Databases"
                    }
                ]
            },
            {
                "slug": "php",
                "name": "PHP",
                "confidence": 100,
                "version": null,
                "icon": "PHP.svg",
                "website": "http://php.net",
                "cpe": "cpe:/a:php:php",
                "categories": [
                    {
                        "id": 27,
                        "slug": "programming-languages",
                        "name": "Programming languages"
                    }
                ]
            },
            {
                "slug": "animate-css",
                "name": "animate.css",
                "confidence": 100,
                "version": null,
                "icon": "default.svg",
                "website": "https://daneden.github.io/animate.css/",
                "cpe": null,
                "categories": [
                    {
                        "id": 66,
                        "slug": "ui-frameworks",
                        "name": "UI frameworks"
                    }
                ]
            },
            {
                "slug": "bootstrap",
                "name": "Bootstrap",
                "confidence": 100,
                "version": null,
                "icon": "Bootstrap.svg",
                "website": "https://getbootstrap.com",
                "cpe": "cpe:/a:getbootstrap:bootstrap",
                "categories": [
                    {
                        "id": 66,
                        "slug": "ui-frameworks",
                        "name": "UI frameworks"
                    }
                ]
            },
            {
                "slug": "apache",
                "name": "Apache",
                "confidence": 100,
                "version": null,
                "icon": "Apache.svg",
                "website": "http://apache.org",
                "cpe": "cpe:/a:apache:http_server",
                "categories": [
                    {
                        "id": 22,
                        "slug": "web-servers",
                        "name": "Web servers"
                    }
                ]
            },
            {
                "slug": "jquery-ui",
                "name": "jQuery UI",
                "confidence": 100,
                "version": "1.9.1",
                "icon": "jQuery UI.svg",
                "website": "http://jqueryui.com",
                "cpe": "cpe:/a:jquery:jquery_ui",
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "slick",
                "name": "Slick",
                "confidence": 100,
                "version": null,
                "icon": "default.svg",
                "website": "https://kenwheeler.github.io/slick",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "owl-carousel",
                "name": "OWL Carousel",
                "confidence": 100,
                "version": null,
                "icon": "OWL Carousel.png",
                "website": "https://owlcarousel2.github.io/OwlCarousel2/",
                "cpe": null,
                "categories": [
                    {
                        "id": 5,
                        "slug": "widgets",
                        "name": "Widgets"
                    }
                ]
            },
            {
                "slug": "lightbox",
                "name": "Lightbox",
                "confidence": 100,
                "version": null,
                "icon": "Lightbox.png",
                "website": "http://lokeshdhakar.com/projects/lightbox2/",
                "cpe": "cpe:/a:lightbox_photo_gallery_project:lightbox_photo_gallery",
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "google-font-api",
                "name": "Google Font API",
                "confidence": 100,
                "version": null,
                "icon": "Google Font API.png",
                "website": "http://google.com/fonts",
                "cpe": null,
                "categories": [
                    {
                        "id": 17,
                        "slug": "font-scripts",
                        "name": "Font scripts"
                    }
                ]
            },
            {
                "slug": "font-awesome",
                "name": "Font Awesome",
                "confidence": 100,
                "version": null,
                "icon": "font-awesome.svg",
                "website": "https://fontawesome.com/",
                "cpe": null,
                "categories": [
                    {
                        "id": 17,
                        "slug": "font-scripts",
                        "name": "Font scripts"
                    }
                ]
            },
            {
                "slug": "prettyphoto",
                "name": "prettyPhoto",
                "confidence": 100,
                "version": null,
                "icon": "prettyPhoto.png",
                "website": "http://no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "jquery-migrate",
                "name": "jQuery Migrate",
                "confidence": 100,
                "version": "3.3.2",
                "icon": "jQuery.svg",
                "website": "https://github.com/jquery/jquery-migrate",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "jquery",
                "name": "jQuery",
                "confidence": 100,
                "version": "1.10.2",
                "icon": "jQuery.svg",
                "website": "https://jquery.com",
                "cpe": "cpe:/a:jquery:jquery",
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "twitter-emoji-twemoji",
                "name": "Twitter Emoji (Twemoji)",
                "confidence": 100,
                "version": null,
                "icon": "default.svg",
                "website": "https://twitter.github.io/twemoji/",
                "cpe": null,
                "categories": [
                    {
                        "id": 17,
                        "slug": "font-scripts",
                        "name": "Font scripts"
                    }
                ]
            },
            {
                "slug": "segment",
                "name": "Segment",
                "confidence": 100,
                "version": null,
                "icon": "Segment.png",
                "website": "https://segment.com",
                "cpe": null,
                "categories": [
                    {
                        "id": 10,
                        "slug": "analytics",
                        "name": "Analytics"
                    }
                ]
            },
            {
                "slug": "modernizr",
                "name": "Modernizr",
                "confidence": 100,
                "version": "2.7.1",
                "icon": "Modernizr.svg",
                "website": "https://modernizr.com",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "hammer-js",
                "name": "Hammer.js",
                "confidence": 100,
                "version": null,
                "icon": "Hammer.js.png",
                "website": "https://hammerjs.github.io",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "google-analytics",
                "name": "Google Analytics",
                "confidence": 100,
                "version": null,
                "icon": "Google Analytics.svg",
                "website": "http://google.com/analytics",
                "cpe": null,
                "categories": [
                    {
                        "id": 10,
                        "slug": "analytics",
                        "name": "Analytics"
                    },
                    {
                        "id": 61,
                        "slug": "saas",
                        "name": "SaaS"
                    }
                ]
            }
        ]
    }
}
this.RESPONSE_FRAMEWORK = {
    "frameworks": {
        "urls": {
            "https://itu.edu.pk/": {
                "status": 200
            }
        },
        "technologies": [
            {
                "slug": "wordpress",
                "name": "WordPress",
                "confidence": 100,
                "version": "5.6",
                "icon": "WordPress.svg",
                "website": "https://wordpress.org",
                "cpe": "cpe:/a:wordpress:wordpress",
                "categories": [
                    {
                        "id": 1,
                        "slug": "cms",
                        "name": "CMS"
                    },
                    {
                        "id": 11,
                        "slug": "blogs",
                        "name": "Blogs"
                    }
                ]
            },
            {
                "slug": "mysql",
                "name": "MySQL",
                "confidence": 100,
                "version": null,
                "icon": "MySQL.svg",
                "website": "http://mysql.com",
                "cpe": "cpe:/a:mysql:mysql",
                "categories": [
                    {
                        "id": 34,
                        "slug": "databases",
                        "name": "Databases"
                    }
                ]
            },
            {
                "slug": "php",
                "name": "PHP",
                "confidence": 100,
                "version": null,
                "icon": "PHP.svg",
                "website": "http://php.net",
                "cpe": "cpe:/a:php:php",
                "categories": [
                    {
                        "id": 27,
                        "slug": "programming-languages",
                        "name": "Programming languages"
                    }
                ]
            },
            {
                "slug": "animate-css",
                "name": "animate.css",
                "confidence": 100,
                "version": null,
                "icon": "default.svg",
                "website": "https://daneden.github.io/animate.css/",
                "cpe": null,
                "categories": [
                    {
                        "id": 66,
                        "slug": "ui-frameworks",
                        "name": "UI frameworks"
                    }
                ]
            },
            {
                "slug": "bootstrap",
                "name": "Bootstrap",
                "confidence": 100,
                "version": null,
                "icon": "Bootstrap.svg",
                "website": "https://getbootstrap.com",
                "cpe": "cpe:/a:getbootstrap:bootstrap",
                "categories": [
                    {
                        "id": 66,
                        "slug": "ui-frameworks",
                        "name": "UI frameworks"
                    }
                ]
            },
            {
                "slug": "apache",
                "name": "Apache",
                "confidence": 100,
                "version": null,
                "icon": "Apache.svg",
                "website": "http://apache.org",
                "cpe": "cpe:/a:apache:http_server",
                "categories": [
                    {
                        "id": 22,
                        "slug": "web-servers",
                        "name": "Web servers"
                    }
                ]
            },
            {
                "slug": "jquery-ui",
                "name": "jQuery UI",
                "confidence": 100,
                "version": "1.9.1",
                "icon": "jQuery UI.svg",
                "website": "http://jqueryui.com",
                "cpe": "cpe:/a:jquery:jquery_ui",
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "slick",
                "name": "Slick",
                "confidence": 100,
                "version": null,
                "icon": "default.svg",
                "website": "https://kenwheeler.github.io/slick",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "owl-carousel",
                "name": "OWL Carousel",
                "confidence": 100,
                "version": null,
                "icon": "OWL Carousel.png",
                "website": "https://owlcarousel2.github.io/OwlCarousel2/",
                "cpe": null,
                "categories": [
                    {
                        "id": 5,
                        "slug": "widgets",
                        "name": "Widgets"
                    }
                ]
            },
            {
                "slug": "lightbox",
                "name": "Lightbox",
                "confidence": 100,
                "version": null,
                "icon": "Lightbox.png",
                "website": "http://lokeshdhakar.com/projects/lightbox2/",
                "cpe": "cpe:/a:lightbox_photo_gallery_project:lightbox_photo_gallery",
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "google-font-api",
                "name": "Google Font API",
                "confidence": 100,
                "version": null,
                "icon": "Google Font API.png",
                "website": "http://google.com/fonts",
                "cpe": null,
                "categories": [
                    {
                        "id": 17,
                        "slug": "font-scripts",
                        "name": "Font scripts"
                    }
                ]
            },
            {
                "slug": "font-awesome",
                "name": "Font Awesome",
                "confidence": 100,
                "version": null,
                "icon": "font-awesome.svg",
                "website": "https://fontawesome.com/",
                "cpe": null,
                "categories": [
                    {
                        "id": 17,
                        "slug": "font-scripts",
                        "name": "Font scripts"
                    }
                ]
            },
            {
                "slug": "prettyphoto",
                "name": "prettyPhoto",
                "confidence": 100,
                "version": null,
                "icon": "prettyPhoto.png",
                "website": "http://no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "jquery-migrate",
                "name": "jQuery Migrate",
                "confidence": 100,
                "version": "3.3.2",
                "icon": "jQuery.svg",
                "website": "https://github.com/jquery/jquery-migrate",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "jquery",
                "name": "jQuery",
                "confidence": 100,
                "version": "1.10.2",
                "icon": "jQuery.svg",
                "website": "https://jquery.com",
                "cpe": "cpe:/a:jquery:jquery",
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "twitter-emoji-twemoji",
                "name": "Twitter Emoji (Twemoji)",
                "confidence": 100,
                "version": null,
                "icon": "default.svg",
                "website": "https://twitter.github.io/twemoji/",
                "cpe": null,
                "categories": [
                    {
                        "id": 17,
                        "slug": "font-scripts",
                        "name": "Font scripts"
                    }
                ]
            },
            {
                "slug": "segment",
                "name": "Segment",
                "confidence": 100,
                "version": null,
                "icon": "Segment.png",
                "website": "https://segment.com",
                "cpe": null,
                "categories": [
                    {
                        "id": 10,
                        "slug": "analytics",
                        "name": "Analytics"
                    }
                ]
            },
            {
                "slug": "modernizr",
                "name": "Modernizr",
                "confidence": 100,
                "version": "2.7.1",
                "icon": "Modernizr.svg",
                "website": "https://modernizr.com",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "hammer-js",
                "name": "Hammer.js",
                "confidence": 100,
                "version": null,
                "icon": "Hammer.js.png",
                "website": "https://hammerjs.github.io",
                "cpe": null,
                "categories": [
                    {
                        "id": 59,
                        "slug": "javascript-libraries",
                        "name": "JavaScript libraries"
                    }
                ]
            },
            {
                "slug": "google-analytics",
                "name": "Google Analytics",
                "confidence": 100,
                "version": null,
                "icon": "Google Analytics.svg",
                "website": "http://google.com/analytics",
                "cpe": null,
                "categories": [
                    {
                        "id": 10,
                        "slug": "analytics",
                        "name": "Analytics"
                    },
                    {
                        "id": 61,
                        "slug": "saas",
                        "name": "SaaS"
                    }
                ]
            }
        ]
    }
}