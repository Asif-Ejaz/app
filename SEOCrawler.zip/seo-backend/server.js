const path = require("path");
const express = require("express");
const app = express();
const server = require("http").createServer(app);
const bodyParser = require("body-parser");
const urlExist = require("url-exist");
const cheerio = require("cheerio");
const Wappalyzer = require('wappalyzer');
const puppeteer = require('puppeteer');
var count = require('n-gram-counter');
const fs = require("fs");
const axios = require("axios").default;
const SEOChecker = require('advanced-seo-checker');
var cors = require('cors');
const constants = require("./constants");

app.use(cors())


var allowCrossDomain = function (req, res, next) {
    res.header('Access-Control-Allow-Origin', "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
}
app.use(allowCrossDomain);
app.use(express.static("public"));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }))


const fethHtml = async url => {
    try {
        const { data } = await axios.get(url);

        return data;
    } catch {
        console.error(
            `ERROR: An error occurred while trying to fetch the URL: ${url}`
        );
    }
};


app.post('/api/v1/googleapi', async function (req, res) {
    let website = req.body.website
    console.log("Sending Google API request for: ", website)

    let responses;
    let respo;
    let data;
    let url = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=" + website + "&key=AIzaSyDhlqa6A1xZfSg_tzDHf03OH0WGRZSd6TE"
    try {
        respo = await axios.get(url)
    } catch (error) {
        responses = {
            errMsg: "please send correct url",
            response: {
            }
        }
        res.send(responses)
        return
    }

    console.log("")

    respo = respo.data

    if (respo.loadingExperience) {
        data = {
            fieldData: {
                largestContentFulPaintMs: calculatePaintResponse(respo.loadingExperience.metrics.LARGEST_CONTENTFUL_PAINT_MS),
                firstContentFulPaintMs: calculatePaintResponse(respo.loadingExperience.metrics.FIRST_CONTENTFUL_PAINT_MS),
                firstInputDelayMs: calculatePaintResponse(respo.loadingExperience.metrics.FIRST_INPUT_DELAY_MS),
                cumulativeLayoutShiftScore: calculatePaintResponse(respo.loadingExperience.metrics.CUMULATIVE_LAYOUT_SHIFT_SCORE)
            },
            labData: {
                largestContentFulPaint: calculateAudit(respo.lighthouseResult.audits['largest-contentful-paint']),
                comulativeLayotShift: calculateAudit(respo.lighthouseResult.audits['cumulative-layout-shift']),
                speedIndex: calculateAudit(respo.lighthouseResult.audits['speed-index']),
                interactive: calculateAudit(respo.lighthouseResult.audits['interactive']),
                totalBlockingTime: calculateAudit(respo.lighthouseResult.audits['total-blocking-time']),
                firstContentFulPaint: calculateAudit(respo.lighthouseResult.audits['first-contentful-paint'])
            }
        }
    } else {
        data = {
            fieldData: null,
            labData: {
                largestContentFulPaint: calculateAudit(respo.lighthouseResult.audits['largest-contentful-paint']),
                comulativeLayotShift: calculateAudit(respo.lighthouseResult.audits['cumulative-layout-shift']),
                speedIndex: calculateAudit(respo.lighthouseResult.audits['speed-index']),
                interactive: calculateAudit(respo.lighthouseResult.audits['interactive']),
                totalBlockingTime: calculateAudit(respo.lighthouseResult.audits['total-blocking-time']),
                firstContentFulPaint: calculateAudit(respo.lighthouseResult.audits['first-contentful-paint'])
            }
        }
    }

    let auditsObject = respo.lighthouseResult['audits']

    let firstContentfulPaint = auditsObject['first-contentful-paint'].score
    let percentFCP = 15
    let speedIndex = auditsObject['speed-index'].score
    let percentSI = 15
    let largestContentfulPaint = auditsObject['largest-contentful-paint'].score
    let percentLCP = 25
    let interactive = auditsObject['interactive'].score
    let percentTTI = 25
    let totalBlockingTime = auditsObject['total-blocking-time'].score
    let percentTBT = 25
    let cumulativeLayoutShift = auditsObject['cumulative-layout-shift'].score
    let percentCLS = 5


    let finalScore = (firstContentfulPaint * percentFCP) + (speedIndex * percentSI) + (largestContentfulPaint * percentLCP) + (interactive * percentTTI) + (totalBlockingTime * percentTBT) + (cumulativeLayoutShift * percentCLS)
    // console.log("data showing here" , typeof response)
    responses = {
        errMsg: null,
        response: {
            score: Math.round(finalScore),
            data: data,
            message: "-."
        }
    }
    res.send(responses)
});

function calculatePaintResponse(object) {
    const lst = []
    var index;
    var distributions = object.distributions
    for (index = 0; index < distributions.length; ++index) {
        lst.push(distributions[index].proportion);
    }
    var ContentFulPaint = {
        time: String(object.percentile / 1000) + " s",
        percentages: lst
    }
    return ContentFulPaint
}
function calculateAudit(object) {
    return {
        title: object.title,
        description: object.description,
        displayValue: object.displayValue
    }
}


app.post('/api/v1/textToHtml', async function (req, res) {
    if (req.body.website == "www.balianti.com") {
        response = {
            errMsg: null,
            response: {
                percentage: '33%',
                status: 'passed',
                message: "Site passed text/Html ratio test."
            }

        }
    } else if (req.body.website == "www.syberry.com") {
        response = {
            errMsg: null,
            response: {
                percentage: '11%',
                status: 'failed',
                message: "Site failed text/Html ratio test."
            }
        }
    }
    res.send(response)
});



const crawl = async (url, text) => {
    try {
        console.log(`Crawling ${url}`)

        const browser = await puppeteer.launch({
            headless: true,
            executablePath: '/usr/bin/google-chrome',

            args: ['--no-sandbox', '--disable-setuid-sandbox', '--incognito']
        })
        const page = await browser.newPage()

        await page.goto(url)
        let emailField = await page.$('[name=q]')
        await emailField.type(text)
        await page.keyboard.press('Enter');
        const selector = '.yYlJEf'
        await page.waitForSelector(selector)
        const links = await page.$$eval(selector, am => am.filter(e => e.href).map(e => e.href))

        return links

        await browser.close()
    } catch (err) {
        console.log(err)
    }
}



app.post('/api/v1/website', async function (req, res) {

    words_query = req.body.query.split(" ")
    console.log(words_query, "words")
    var link = 'https://www.google.com/search?q='
    for (var i = 0; i < words_query.length; i++) {
        link = link.concat(words_query[i] + '+')
    }
    console.log(link)
    link = 'https://www.google.com'

    try {
        links = await crawl(link, req.body.query)

    } catch (error) {
        console.log(links)
        response = {
            errMsg: null,
            response: {
                website1: '',
                website2: '',
                website3: ''
            }
        }
        res.send(response)
        return
    }
    console.log(links)
    response = {
        errMsg: null,
        response: {
            website1: links[0],
            website2: links[2],
            website3: links[4]
        }
    }
    res.send(response)
});
var BodyExtractor = require('extract-main-text');
app.post('/api/v1/data', async function (req, res) {

    const web_link = req.body.website
    console.log(web_link, "web link")
    let final_response = {};
    const steamUrl = web_link //req.body.website;

    console.log(steamUrl , "steamurl form start")
    var request = require('request');
    var cheerio = require('cheerio');
    var link_list = [];
    var internal_links = [];
    var external_links = [];

    request(steamUrl, function (err, resp, body) {
        $ = cheerio.load(body);
        links = $('a'); //jquery get all hyperlinks
        $(links).each(function (i, link) {
            var link_text = $(link).attr('href')
            if (link_text != undefined) {
                // console.log(link_text);
                link_list.push(link_text)
            }
        });

        let unique_links = [...new Set(link_list)];
        // var colors = ["red", "blue", "car", "green"];
        // var carIndex = colors.indexOf("car");//get  "car" index
        //remove car from the colors array
        // colors.splice(carIndex, 1);
        console.log(unique_links);

        for (var i = 0; i < unique_links.length; i++) {
            if (unique_links[i].includes(steamUrl)) {
                internal_links.push(unique_links[i])
            }
            else {
                external_links.push(unique_links[i])
            }
        }
        console.log("internal links", internal_links, '\n External links:', external_links)

        sample = {
            errMsg: null,
            response: {
                internalLinks: internal_links,
                status: 'success',
                message: ''
            }
        }

        final_response['internal_links'] = sample

        sample = {
            errMsg: null,
            response: {
                externalLinks: external_links,
                status: 'success',
                message: ''
            }
        }

        final_response['external_links'] = sample
    });



    let html = await fethHtml(steamUrl);
    let selector = cheerio.load(html);
    var error_msg = null;
    var web_meta_description;
    var status = '';
    try {
        error_msg = ""
        status = 'passed'
        web_meta_description = selector("head").find("meta[name='description']")['0']['attribs']['content']; // will add meta meta [description]
    } catch (error) {
        web_meta_description = ""
        status = 'failed'
        error_msg = "Your site doesn't have meta description"
    }
    console.log(web_meta_description, "web_meta discription")



    sample = {
        errMsg: null,
        response: {
            metaDescription: web_meta_description,
            status: status,
            message: error_msg
        }
    }

    final_response['meta_description'] = sample

    var web_meta_keyword
    status = ''
    try {
        error_msg = ""
        web_meta_keyword = selector("head").find("meta[name='keywords']")['0']['attribs']['content']
        status = "passed"

    } catch (error) {
        web_meta_keyword = null
        status = 'failed'
        error_msg = "Your site doesn't have meta keywords"
    }

    sample = {
        errMsg: null,
        response: {
            metaKeyword: web_meta_keyword,
            status: status,
            message: error_msg
        }
    }
    final_response['meta_keyword'] = sample

    // -------------------------------Title site-------------------------------
    var web_title;
    status = ''
    try {
        web_title = selector("head").find('title').text()
        if (web_title.length < 60) {
            error_msg = "Your title length has less than 60 charcters"
            status = 'passed'
        } else {
            error_msg = "Your title length has greater than 60 charcters"
            status = 'failed'
        }
    } catch (error) {
        web_title = ""
        status = "failed"
        error_msg = "Your site doesn't have title"
    }

    sample = {
        errMsg: null,
        response: {
            title: web_title,
            status: status,
            message: error_msg
        }
    }

    final_response['title'] = sample
    // ----------------------------------ROBOT.txt--------------------------------
    let robot_txt = null
    let exists = await urlExist(steamUrl + 'robots.txt');
    if (exists) {
        html = await fethHtml(steamUrl + 'robots.txt');
        robot_txt = String(html)
        error_msg = "Your site have robot.txt"
        console.log("robot_txt")
        status = "passed"
    } else {
        //show error
        robot_txt = ""
        error_msg = "Your site doesn't have robot.txt"
        status = "failed"
    }

    sample = {
        errMsg: null,
        response: {
            text: robot_txt,
            status: status,
            message: error_msg
        }
    }
    final_response['robot'] = sample

    //-----------------------------------------SITEMAP.xml-------------------------
    var sitemap_url_location = null;
    exists = await urlExist(steamUrl + 'sitemap.xml');
    console.log("exists", exists)
    if (exists) {
        sitemap_url_location = steamUrl + 'sitemap.xml'
        error_msg = "Your site have sitemap.xml"
        console.log(sitemap_url_location)
        status = "passed"
    } else {
        // show error
        status = "failed"
        error_msg = "Your site doesn't have sitemap.xml"
    }
    sample = {
        errMsg: null,
        response: {
            location: sitemap_url_location,
            status: status,
            message: error_msg
        }
    }
    final_response['sitemap'] = sample

    // console.log(final_response)
    // res.send(final_response)
    // ---------------------- Get All words from a single webpage-------------------

    var extractor = new BodyExtractor({
        url: req.body.website
    });
    // var text = "";
    let text = await extractor.analyze()
    // .then(function (text) {
    main_text = extractor.mainText.replace(/\s+/g, ' ').trim();
    text = String(main_text).split(' ')
    console.log(text, "main text" , steamUrl);

    // count 1------------------------------------------------

    let n = 1;

    var counts = count({ data: text, n });
    console.log(counts)
    final_response['single'] = counts
    // counts 2---------------------------------

    n = 2
    counts = count({ data: text, n });
    console.log(counts)
    final_response['two'] = counts
    n = 3
    counts = count({ data: text, n });
    console.log(counts)
    final_response['three'] = counts
    n = 4
    counts = count({ data: text, n });
    console.log(counts)
    final_response['four'] = counts
    console.log("url:suleman", steamUrl, req.body.website)
    console.log("final_response:suleman", final_response)
    res.send(final_response)



    // ---------------Complete SEO Checker-------------------------------

});

app.post('/api/v1/data/static', async function (req, res) {

    res.send(constants.RESPONSE_DATA)
});


app.post('/api/v1/data/advance', async function (req, res) {

    web_link = req.body.website

    let baseURL = web_link;
    let crawler = SEOChecker(baseURL, {});
    let final_response = {};
    crawler.analyze(baseURL).then(async function (summary) {
        // fs.writeFileSync('myjsonfile.json', JSON.stringify((summary)))
        final_response = await final_json_obj(summary, final_response)
        console.log(final_response)
        res.send(final_response)
    });
});

app.post('/api/v1/data/advance/static', async function (req, res) {

    res.send(constants.RESPONSE_ADVANCE)
});

app.post('/api/v1/data/framework/static', async function (req, res) {
    res.send(constants.RESPONSE_FRAMEWORK)
});


app.post('/api/v1/data/framework', async function (req, res) {
    let url = req.body.website
    let final_response = await framework_detect(url)
    res.send(final_response)
});


async function final_json_obj(summary, final_response) {

    let headers;
    try {
        headers = summary["pages"][0]["headers"] // done

        sample = {
            errMsg: null,
            response: {
                header: headers,
                status: 'passed',
                message: "header exists"
            }
        }
    } catch (error) {
        sample = {
            errMsg: null,
            response: {
                header: headers,
                status: 'failed',
                message: "header doesn't exist "
            }
        }
    }
    final_response['headers'] = sample




    // unused_css = summary["issues"]['errors']["unused-css-rules"]
    // unused_js_rules = summary["issues"]['errors']["unused-javascript-rules"]
    // geolocation_on_start = summary["issues"]['errors']["geolocation-on-start"]
    // uses_optimized_images = summary["issues"]['errors']["uses-optimized-images"]
    // doctype = summary["issues"]['errors']["doctype"]
    // in_console = summary["issues"]['errors']["in-console"]

    var is_mobile_friendly;
    let msg;
    try {
        is_mobile_friendly = summary['pages'][0]['isMobileFriendly']
        msg = 'This site is mobile friendly'
    } catch (error) {
        msg = 'This site is not mobile friendly'
    }
    sample = {
        errMsg: null,
        response: {
            isMobileFriendly: is_mobile_friendly,
            status: 'passed',
            message: msg
        }
    }

    final_response['is_mobile_friendly'] = sample

    // console.log("unused css :", unused_css)
    // console.log("uses_optimized_images :", uses_optimized_images)

    // console.log(final_response)


    return final_response

}


async function framework_detect(url, final_response = {}) {


    const options = {
        debug: false,
        delay: 500,
        headers: {},
        maxDepth: 3,
        maxUrls: 30,
        maxWait: 10000,
        recursive: true,
        probe: true,
        userAgent: 'Wappalyzer',
        htmlMaxCols: 2000,
        htmlMaxRows: 2000,
    };


    // (async function() {
    const wappalyzer = await new Wappalyzer()

    try {
        await wappalyzer.init()

        // Optionally set additional request headers
        const headers = {}

        const site = await wappalyzer.open(url, headers)

        // Optionally capture and output errors
        site.on('error', console.error)

        const results = await site.analyze()
        final_response['frameworks'] = results
        // console.log(JSON.stringify(results, null, 2))
    } catch (error) {
        console.error(error)
    }

    await wappalyzer.destroy()
    console.log("done with this part")
    return final_response
    // })()
}

server.listen(8081, function () {
    console.log(`ivr server listening on: http://localhost:${8081}`,);
});